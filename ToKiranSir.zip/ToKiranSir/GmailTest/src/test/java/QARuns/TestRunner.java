package QARuns;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import projSpecific.LoginTest;

public class TestRunner extends LoginTest{
	

	
	@BeforeMethod
	public static void initial(){
		try {
			initialize("chrome",System.getProperty("user.dir")+"\\config.properties","url");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	@Test(priority=1)
	public void TC_01_Loginwithusernameandpwd(){
	
		try {
		boolean	val =ValidUserNameAndPwd();
		Assert.assertEquals(val, true);
		
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	@Test(priority=2)	
	public void TC_02_NoValidUserName(){
		
		try {

			
			boolean	val =NoValidUserName();
			Assert.assertEquals(val, true);

			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	@Test(priority=3)
	public static void TC_03_NoValidPwd() {
		
		
		boolean	val =ValidUserNameAndNoPwd();
		Assert.assertEquals(val, true);
		
}
		
				
	@AfterMethod
	public static void LogoutAfterTest(){
	
		driver_quit();
		
	}
	
			
	}

