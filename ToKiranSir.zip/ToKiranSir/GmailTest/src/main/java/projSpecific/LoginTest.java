package projSpecific;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import utilityFn.*;

public class LoginTest extends Utility {

	
	public static void logout() throws Exception {

		Actions act = new Actions(driver);
		act.moveToElement(driver.findElement(
				By.xpath(LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "signout_xpath"))))
				.click().build().perform();

	}

	
	/*************************************************************************************************************************************************************************
	 											This is the testcase with valid username and password
	
	*************************************************************************************************************************************************************************/
	
	public static boolean ValidUserNameAndPwd() {

		boolean rval = true;
		try {

			
			LoadFmProperty(System.getProperty("user.dir") + "\\config.properties", "usename_xpath");
			InputString(LoadFmProperty(System.getProperty("user.dir") + "\\config.properties", "usename"),
					LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "usename_xpath"));
			ClickElement(LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "Next"));
			
			
			
			InputString(LoadFmProperty(System.getProperty("user.dir") + "\\config.properties", "password"),
					LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "pwd_xpath"));
			ClickElement(LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "Next"));
			ClickElement(LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "Logout_xpath"));
			
		} catch (Exception e) {

			rval = false;
		}
		
		try {
			logout();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rval;
	}

	
	
	/*************************************************************************************************************************************************************************
										
										This is the testcase without providing username

	 *************************************************************************************************************************************************************************/

	
	
	
	public static boolean NoValidUserName() {

		boolean rval = true;
		
		try {
			LoadFmProperty(System.getProperty("user.dir") + "\\config.properties", "usename_xpath");
			InputString(LoadFmProperty(System.getProperty("user.dir") + "\\config.properties", "usename"), "");
			ClickElement(LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "Next"));

			if (getText(System.getProperty("user.dir") + "\\xpath.properties", "errortxt")
					.equals(LoadFmProperty(System.getProperty("user.dir") + "\\config.properties", "Error_text")))
				;
			{

				rval = true;

			}

			
		}

		catch (Exception e) {
			
			rval = false;
		}

		return rval;
		
	
	}

	
	
	/*************************************************************************************************************************************************************************
		
	
		This is the testcase with valid username and without providing password


	 *************************************************************************************************************************************************************************/

	
	
	
	public static boolean ValidUserNameAndNoPwd() {

		boolean rval = true;
		
		try {
			LoadFmProperty(System.getProperty("user.dir") + "\\config.properties", "usename_xpath");
			InputString(LoadFmProperty(System.getProperty("user.dir") + "\\config.properties", "usename"),
					LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "usename_xpath"));
			ClickElement(LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "Next"));
			InputString("", LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "pwd_xpath"));
			ClickElement(LoadFmProperty(System.getProperty("user.dir") + "\\xpath.properties", "Next"));
			if (getText(System.getProperty("user.dir") + "\\xpath.properties", "pwd_err_xpath")
					.equals(LoadFmProperty(System.getProperty("user.dir") + "\\config.properties", "Erro_text_pwd")))
				;
			
			{

							}
		} catch (Exception e) {
			rval = false;
		}

		return rval;

		
	}

}
