package utilityFn;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Utility {

	public static Properties prop;
	protected static WebDriver driver;

	/**************************************************************************************************************************************************************************
	 * 
	 * This functions returns the property values form the property files i/p
	 * property file path and prop value mentioned in the property file prop
	 * values can be strings as well as xpaths
	 * 
	 * /
	 **************************************************************************************************************************************************************************/

	public static String LoadFmProperty(String pathtopropfile, String propstr) throws Exception {

		prop = new Properties();
		FileInputStream fi = new FileInputStream(pathtopropfile);
		prop.load(fi);
		return prop.getProperty(propstr);

	}

	/**************************************************************************************************************************************************************************
	 * 
	 * This method helps to select and initialize the webdriver
	 * 
	 * i/p's browser type, property file path and prop value mentioned in the
	 * property file
	 * 
	 * /
	 **************************************************************************************************************************************************************************/

	public static void initialize(String Browswer, String pathtopropfile, String propstr) throws Exception {

		if (Browswer.equals("chrome")) {

			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.get(LoadFmProperty(pathtopropfile, propstr));
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		} else if (Browswer.equals("FireFox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			driver.get(LoadFmProperty(pathtopropfile, propstr));
			driver.manage().window().maximize();
			driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}

	}

	/**************************************************************************************************************************************************************************
	 * 
	 * This method enters the user input string into Textboxes
	 * 
	 * i/p's Text to enter and xpath value for the webelement
	 * 
	 * 
	 * /
	 **************************************************************************************************************************************************************************/

	public static void InputString(String str, String xpath) {

		for (int i = 1; i <= 5; i++) {
			try {
				boolean bval = true;
				if (bval == driver.findElement(By.xpath(xpath)).isEnabled()) {
					driver.findElement(By.xpath(xpath)).sendKeys(str);
				}

				break;
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		}

	}

	/**************************************************************************************************************************************************************************
	 * 
	 * This method performs the click operation on webelement i/p's xapth value
	 * mentioned in the propert file
	 * 
	 * 
	 **************************************************************************************************************************************************************************/

	public static void ClickElement(String xpath) {

		for (int i = 1; i <= 5; i++) {
			try {
				boolean bval = true;
				if (bval == driver.findElement(By.xpath(xpath)).isEnabled()) {
					driver.findElement(By.xpath(xpath)).click();
				}

				break;
			} catch (Exception e) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		}

	}

	/**************************************************************************************************************************************************************************
	 * 
	 * This method is used capture the strings from the webelement i/p's
	 * property file path and prop value mentioned in the property file
	 * 
	 * /
	 **************************************************************************************************************************************************************************/

	public static String getText(String pathtopropfile, String propstr) throws Exception {

		String actual = driver.findElement(By.xpath(LoadFmProperty(pathtopropfile, propstr))).getText();
		return actual;

	}

	/**************************************************************************************************************************************************************************
	 * 
	 * This method is used to close the all opened browser windows
	 * 
	 * 
	 * /
	 **************************************************************************************************************************************************************************/

	public static void driver_quit() {

		driver.quit();

	}

}
